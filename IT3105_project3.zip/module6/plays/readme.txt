This is the folder where AI play logs will be stored.
