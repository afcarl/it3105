from blind_test import ann
import demo

"""
This is the python file that should be run during the demo it calls minor_test with the proper
ann class that has the blind_test method
"""

demo.minor_demo(ann)
